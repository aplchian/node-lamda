`sls deploy`

`sls invoke --function helloWorld --log`

`curl -X POST https://7ew5oo9bfi.execute-api.us-east-1.amazonaws.com/dev/todos --data '{"test": "this is a todo"}'`